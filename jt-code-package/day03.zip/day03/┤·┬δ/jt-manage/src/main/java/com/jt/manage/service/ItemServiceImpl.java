package com.jt.manage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jt.common.po.Item;
import com.jt.manage.mapper.ItemMapper;
import com.jt.manage.vo.EasyUI_Data;

@Service
public class ItemServiceImpl implements ItemService {
	
	@Autowired
	private ItemMapper itemMapper;

	@Override
	public EasyUI_Data findItemByPage(Integer page, Integer rows) {
		int total = itemMapper.findCount(); //商品记录总数
		
		/**
		 * SELECT * FROM tb_item LIMIT 起始位置,查询记录数
		查询第一页
		SELECT * FROM tb_item LIMIT 0,20  (0-19)
		查询第二页
		SELECT * FROM tb_item LIMIT 20,20 (20-39)	
		查询第N页
		SELECT * FROM tb_item LIMIT (n-1)*20,20*/
		int start = (page - 1) * rows;
		List<Item> itemList = 
				itemMapper.findItemByPage(start,rows);
		
		//分页后 查询的结果
		return new EasyUI_Data(total,itemList);
	}
	
	
	@Override
	public String findItemCatNameById(Long itemId) {
		
		return itemMapper.findItemCatNameById(itemId);
	}
}
