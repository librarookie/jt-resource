package com.jt.manage.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jt.common.po.ItemCat;
import com.jt.manage.mapper.ItemCatMapper;
import com.jt.manage.vo.EasyUI_Tree;

@Service
public class ItemCatServiceImpl implements ItemCatService {
	
	@Autowired
	private ItemCatMapper itemCatMapper;
	
	public List<ItemCat> findItemCatByParentId(Long parentId){
		ItemCat itemCat = new ItemCat();
		itemCat.setParentId(parentId);
		//基于通用Mapper查询数据信息
		return itemCatMapper.select(itemCat);
	}
	@Override
	public List<EasyUI_Tree> findTree(Long parentId) {
		List<ItemCat> catList = 
				findItemCatByParentId(parentId);
		List<EasyUI_Tree> treeList = new ArrayList<>();
		for (ItemCat itemCat : catList) {
			EasyUI_Tree tree = new EasyUI_Tree();
			tree.setId(itemCat.getId());
			tree.setText(itemCat.getName());
			String state = 
				itemCat.getIsParent() ? "closed" : "open";
			tree.setState(state);
			treeList.add(tree);
		}
		return treeList;
	}
}
