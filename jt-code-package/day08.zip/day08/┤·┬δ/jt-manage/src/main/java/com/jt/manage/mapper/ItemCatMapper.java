package com.jt.manage.mapper;

import com.jt.common.mapper.SysMapper;
import com.jt.common.po.ItemCat;

public interface ItemCatMapper extends SysMapper<ItemCat>{

}
