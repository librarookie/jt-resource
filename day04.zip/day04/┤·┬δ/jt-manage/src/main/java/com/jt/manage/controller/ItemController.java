package com.jt.manage.controller;


import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jt.common.po.Item;
import com.jt.common.vo.SysResult;
import com.jt.manage.service.ItemService;
import com.jt.manage.vo.EasyUI_Data;

@Controller
@RequestMapping("/item")
public class ItemController {
	
	@Autowired
	private ItemService itemService;
	
	//实现商品列表的分页查询
	@RequestMapping("/query")
	@ResponseBody	//将数据转化为JSON
	public EasyUI_Data findItemByPage(Integer page,Integer rows) {
		
		return itemService.findItemByPage(page,rows);
	}
	
	/**
	 * spring4及以下  如果返回值是string类型,则采用ISO-8859-1格式转码
	 *    如果返回值是对象,则采用UTF-8格式编码
	 * 
	 *  StringHttpMessageConverter
	 *  public static final Charset DEFAULT_CHARSET = Charset.forName("ISO-8859-1");
	 * 	
	 * 	AbstractJackson2HttpMessageConverter
	 * 	public static final Charset DEFAULT_CHARSET = Charset.forName("UTF-8");
	 * @param itemId
	 * @return
	 */
	//根据商品分类ID查询分类名称
	@RequestMapping(value="/cat/queryItemName",
	produces="text/html;charset=utf-8")
	@ResponseBody
	public String findItemCatNameById(Long itemId,
			HttpServletResponse response) {
		
		return itemService.findItemCatNameById(itemId);
	}
	
	//实现商品新增
	@RequestMapping("/save")
	@ResponseBody
	public SysResult saveItem(Item item) {
		try {
			itemService.saveItem(item);
			return SysResult.oK();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return SysResult.build(201,"商品新增失败");
	}
	
	//商品修改
	@RequestMapping("/update")
	@ResponseBody
	public SysResult updateItem(Item item) {
		try {
			itemService.updateItem(item);
			return SysResult.oK();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return SysResult.build(201,"商品修改失败");
	}
	
	//商品下架
	@RequestMapping("/instock")
	@ResponseBody
	public SysResult instockItem(Long[] ids) {
		try {
			int status = 2;  //下架
			itemService.updateStatus(ids,status);
			return SysResult.oK();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return SysResult.build(201,"商品修改状态失败");
	}
	
	//商品上架
	@RequestMapping("/reshelf")
	@ResponseBody
	public SysResult reshelfItem(Long[] ids) {
		try {
			int status = 1;  //下架
			itemService.updateStatus(ids,status);
			return SysResult.oK();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return SysResult.build(201,"商品修改状态失败");
	}
	
	
	
	
}
