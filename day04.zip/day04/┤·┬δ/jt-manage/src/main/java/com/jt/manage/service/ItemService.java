package com.jt.manage.service;

import com.jt.common.po.Item;
import com.jt.manage.vo.EasyUI_Data;

public interface ItemService {

	EasyUI_Data findItemByPage(Integer page, Integer rows);

	String findItemCatNameById(Long itemId);

	void saveItem(Item item);

	void updateItem(Item item);

	void updateStatus(Long[] ids, int status);

}
