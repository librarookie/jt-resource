package com.jt.springcloud.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import com.jt.springcloud.pojo.User;
import com.jt.springcloud.service.UserService;

@RestController
public class UserController {
	
	@Autowired
	private RestTemplate restTemplate;
	private static final String provider_url = "http://provider-user";
	
	@Autowired
	private UserService userService;	//利用API接口方式调用
	
	@SuppressWarnings("unchecked")	//压制警告
	@RequestMapping("/findAll")
	public List<User> findAll(){
		
		return userService.findAll();
	}
	
	//查询单个用户信息
	@RequestMapping("/findUserById/{id}")
	public User findUserById(@PathVariable Integer id) {
		
		return userService.findUserById(id);
	}
	
	//新增用户信息
	@RequestMapping("/saveUser/{name}/{age}/{sex}")
	public String saveUser(User user) {
		
		return userService.saveUser(user);
	}
	
	//修改用户信息
	@RequestMapping("/update/{id}/{name}/{age}/{sex}")
	public String updateUser(User user){
		
		return userService.updateUser(user);
	}
	
	//删除用户信息
	@RequestMapping("/deleteUserById/{id}")
	public String deleteUser(@PathVariable Integer id) {
		
		return userService.deleteUser(id);
	}
	
	@RequestMapping("/getMsg")
	public String getMsg() {
		
		return userService.getMsg();
	}
	
	/**
	 * restTemplate方式访问数据
	//查询用户信息
	@SuppressWarnings("unchecked")	//压制警告
	@RequestMapping("/findAll")
	public List<User> findAll(){
		
		return restTemplate.getForObject(provider_url+"/findAll", List.class);
	}
	
	//查询单个用户信息
	@RequestMapping("/findUserById/{id}")
	public User findUserById(@PathVariable int id) {
		
		return restTemplate.getForObject(provider_url+"/findUserById?id="+id,User.class);
	}
	
	//新增用户信息
	@RequestMapping("/saveUser/{name}/{age}/{sex}")
	public String saveUser(User user) {
		
		return restTemplate.postForObject(provider_url + "/saveUser", user,String.class);
	}
	
	//修改用户信息
	@RequestMapping("/update/{id}/{name}/{age}/{sex}")
	public String updateUser(User user) {
		
		return restTemplate.postForObject(provider_url+"/updateUser", user, String.class);
	}
	
	//删除用户信息
	@RequestMapping("/deleteUserById/{id}")
	public String deleteUser(@PathVariable int id) {
		
		return restTemplate.getForObject(provider_url+"/deleteUserById?id="+id, String.class);
	}
	
	@RequestMapping("/getMsg")
	public String getMsg() {
		
		return restTemplate.getForObject(provider_url+"/getMsg", String.class);
	}
	*/
}
