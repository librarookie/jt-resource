package com.jt.springcloud.factory;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.jt.springcloud.pojo.User;
import com.jt.springcloud.service.UserService;

import feign.hystrix.FallbackFactory;

//定义服务降级  当服务端宕机不能影响时 降级处理
@Component
public class UserServiceFallbackFactroy implements FallbackFactory<UserService>{

	@Override
	public UserService create(Throwable cause) {
		
		return new UserService() {
			
			@Override
			public String updateUser(User user) {
				
				return "服务器更新异常-降级";
			}
			
			@Override
			public String saveUser(User user) {

				return "服务器保存异常-降级";
			}
			
			@Override
			public String getMsg() {
				
				return "服务器降级处理";
			}
			
			@Override
			public User findUserById(Integer id) {
				User user = new User();
				user.setId(0);
				user.setName("服务器异常,降级处理");
				user.setAge(0);
				user.setSex("男");
				return user;
			}
			
			@Override
			public List<User> findAll() {
				User user = new User();
				user.setId(0).setName("服务器异常,降级处理").setAge(0).setSex("");
				List<User> userList = new ArrayList<>();
				userList.add(user);
				return userList;
			}
			
			@Override
			public String deleteUser(Integer id) {
				
				return "服务器异常,降级处理";
			}
		};
	}
	

	
	
}
