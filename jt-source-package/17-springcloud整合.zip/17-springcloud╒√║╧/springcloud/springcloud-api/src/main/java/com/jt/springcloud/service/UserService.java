package com.jt.springcloud.service;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import com.jt.springcloud.factory.UserServiceFallbackFactroy;
import com.jt.springcloud.pojo.User;
@FeignClient(value="provider-user",fallbackFactory=UserServiceFallbackFactroy.class)
public interface UserService {
	
	@RequestMapping("/findAll")
	public List<User> findAll();

	@RequestMapping("/findUserById/{id}")
	public User findUserById(@PathVariable Integer id);
	
	@RequestMapping("/saveUser")
	public String saveUser(@RequestBody User user);
	
	@RequestMapping("/updateUser")
	public String updateUser(@RequestBody User user);
	
	@RequestMapping("/deleteUserById/{id}")
	public String deleteUser(@PathVariable Integer id);
	
	@RequestMapping("/getMsg")
	public String getMsg();
}
