package com.jt.springcloud.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jt.springcloud.pojo.User;
import com.jt.springcloud.service.UserService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
@RestController
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@RequestMapping("/findAll")
	@HystrixCommand(fallbackMethod="hystrix_findAll")
	public List<User> findAll(){
		
		//int a = 1/0;
		return userService.findAll();
	}
	
	//配置断路器
	public List<User> hystrix_findAll(){
		User user = new User();
		user.setId(0).setName("服务器异常").setAge(0).setSex("");
		List<User> userList = new ArrayList<>();
		userList.add(user);
		return userList;
	}
	
	@RequestMapping("/findUserById/{id}")
	public User findUserById(@PathVariable Integer id) {
		
		return userService.findUserById(id);
	}
	
	@RequestMapping("/saveUser")
	public String saveUser(@RequestBody User user) {
		
		userService.saveUser(user);
		return "用户入库成功:name="+user.getName();
	}
	
	@RequestMapping("/updateUser")
	@Transactional
	public String updateUser(@RequestBody User user) {
		
		userService.updateUser(user);
		return "用户修改成功! name="+user.getName();
	}
	
	@RequestMapping("/deleteUserById/{id}")
	public String deleteUser(@PathVariable Integer id) {
		
		userService.deleteUser(id);
		return "用户删除成功! id = "+ id;
	}
	
	@RequestMapping("/getMsg")
	public String getMsg() {
		
		return "第一台服务端获取数据";
	}
	
}
