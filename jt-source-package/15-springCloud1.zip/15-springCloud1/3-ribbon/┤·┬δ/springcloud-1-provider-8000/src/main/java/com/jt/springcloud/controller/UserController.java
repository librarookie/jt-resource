package com.jt.springcloud.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.jt.springcloud.pojo.User;
import com.jt.springcloud.service.UserService;

@RestController
public class UserController {
	
	@Autowired
	public UserService userService;
	
	@RequestMapping("/getMsg")
	public String getMsg() {
		
		return "我是第一台服务端!!!";
	}
	
	@RequestMapping(value="/findAll",method=RequestMethod.GET)
	public List<User> findAll(){
		
		return userService.findAll();
	}
	
	
	@RequestMapping("/saveUser")
	public String saveUser(@RequestBody User user) {
		
		userService.saveUser(user);
		return "用户入库成功";
	}
	
	@RequestMapping("/delete")
	public String deleteUser(Integer id) {
		
		userService.deleteUser(id);
		return "用户删除成功!!";
	}
	
	@RequestMapping("/updateUser")
	public String updateUser(@RequestBody User user) {
		
		userService.updateUser(user);
		return "用户更新成功!!!";
	}
	
	
	
	
	
	
}
