package com.jt.springcloud.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.jt.springcloud.pojo.User;

@RestController
public class UserController {
	
	//private static final String provider_url = "http://localhost:8000";
	private static final String provider_url = "http://PROVIDER-USER";
	@Autowired
	private RestTemplate restTemplate;
	
	@SuppressWarnings("unchecked")	//压制警告
	@RequestMapping("/findAll")
	public List<User> findAll(){
		
		return restTemplate.getForObject(provider_url+"/findAll", List.class);
	}
	
	@RequestMapping("/getMsg")
	public String getMsg() {
		
		return restTemplate.getForObject(provider_url + "/getMsg", String.class);
	}
	
	//新增用户
	@RequestMapping("/saveUser/{name}/{age}/{sex}")
	public String saveUser(User user) {
		
		return restTemplate.postForObject(provider_url + "/saveUser", user, String.class);
	}
	
	//删除用户信息
	@RequestMapping("/delete/{id}")
	public String delUser(@PathVariable Integer id) {
		
		
		return restTemplate.getForObject(provider_url + "/delete?id="+id, String.class);
	}
	
	
	@RequestMapping("/update/{id}/{name}/{age}/{sex}")
	public String updateUser(User user) {
		
		return restTemplate.postForObject(provider_url + "/updateUser", user,String.class);
	}
	
	
	
	
	
	
	
	
	
}
