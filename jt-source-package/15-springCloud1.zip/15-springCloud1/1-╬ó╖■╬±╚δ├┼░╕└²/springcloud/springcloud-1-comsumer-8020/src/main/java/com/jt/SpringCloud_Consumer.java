package com.jt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

@SpringBootApplication(exclude=DataSourceAutoConfiguration.class)
public class SpringCloud_Consumer {
	
	public static void main(String[] args) {
		SpringApplication.run(SpringCloud_Consumer.class, args);
	}
}
