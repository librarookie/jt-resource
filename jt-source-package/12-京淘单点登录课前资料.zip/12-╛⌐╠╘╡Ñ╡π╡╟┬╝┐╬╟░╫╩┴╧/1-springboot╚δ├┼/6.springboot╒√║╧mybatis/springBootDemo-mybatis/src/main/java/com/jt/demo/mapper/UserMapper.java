package com.jt.demo.mapper;

import java.util.List;

import com.jt.demo.pojo.User;

public interface UserMapper {
	
	List<User> findAll();
}
