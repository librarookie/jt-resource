package com.jt.sso.controller;

import java.util.Date;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.codec.digest.Md5Crypt;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jt.common.vo.SysResult;
import com.jt.sso.pojo.User;
import com.jt.sso.service.UserService;

import redis.clients.jedis.JedisCluster;

@Controller
@RequestMapping("/user")
public class UserController {
	private Logger logger = Logger.getLogger(UserController.class);
	
	@Autowired
	private UserService userService;
	@Autowired
	private JedisCluster jedisCluster;
	/**
	 * http://sso.jt.com/user/check/qwerqwer/1?r=0.46835108689746696&callback=jsonp1507820023238&_=1507820947497
	 * 检查数据是否可用
	 * @param param  表示数据
	 * @param type   表示校验类型   1 username、2 phone、3 email
	 * @return
	 * data: false  //返回数据true用户已存在，false用户不存在，可以
	 */
	@RequestMapping("/check/{param}/{type}")
	@ResponseBody
	public Object findcheckUser(@PathVariable String param,@PathVariable Integer type,String callback){
		try {
			Boolean sysData = userService.findCheckUser(param,type);
			MappingJacksonValue jacksonValue = new MappingJacksonValue(SysResult.oK(sysData));
			jacksonValue.setJsonpFunction(callback);
			return jacksonValue;
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			MappingJacksonValue jacksonValue = new MappingJacksonValue(SysResult.build(201, "查询信息已存在"));
			jacksonValue.setJsonpFunction(callback);
			return jacksonValue;
		}
	}

	//注册用户
	@RequestMapping("/register")
	@ResponseBody
	public SysResult register(User user){
		try {
			String username = userService.saveUser(user);
			return SysResult.oK(username);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return SysResult.build(201, "用户新增失败");
		}
	}
	
	//用户登陆
	@RequestMapping("/login")
	@ResponseBody
	public SysResult login(@RequestParam("u")String username,@RequestParam("p")String password){
		try {
			String ticket = userService.login(username,password);
			return SysResult.oK(ticket);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			return SysResult.build(201, "用户登陆失败");
		}
	}
	
	//http://sso.jt.com/user/query/{ticket}  根据ticket查询用户信息 
	@RequestMapping("/query/{ticket}")
	@ResponseBody
	public Object queryUser(String callback,@PathVariable String ticket){
		try {
			//从redis中获取数据
			String userJSON  = jedisCluster.get(ticket);
			MappingJacksonValue jacksonValue = new MappingJacksonValue(SysResult.oK(userJSON));
			jacksonValue.setJsonpFunction(callback);
			return jacksonValue;
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			return SysResult.build(201, "查询失败");
		}
	}
	
	
	
	
	
	
}
