package com.jt.sso.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jt.common.service.BaseService;
import com.jt.sso.mapper.UserMapper;
import com.jt.sso.pojo.User;

import redis.clients.jedis.JedisCluster;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserMapper userMapper;
	
	@Autowired
	private JedisCluster jedisCluster; 
	
	private static final ObjectMapper objectMapper = new ObjectMapper();
	
	@Override  //1 username、2 phone、3 email   data: false  //返回数据true用户已存在，false用户不存在
	public Boolean findCheckUser(String param, Integer type) {
		
		String column = null;  //定义查询的字段名称
		switch(type){
			case 1: column = "username"; break;
			case 2: column = "phone"; break;
			case 3: column = "email"; break;
		}
		
		//如果为 0表示 可以使用  如果为1 表示已经存在
		int count = userMapper.findCheckUser(param,column);
		
		return count==1?true:false;
	}

	@Override
	public String saveUser(User user) {
		//将密码进行加密处理
		user.setPassword(DigestUtils.md5Hex(user.getPassword()));
		user.setCreated(new Date());
		user.setUpdated(user.getCreated());
		user.setEmail(user.getPhone()); //由于页面提交没有邮箱地址,为了防止插入空数据用电话号码代替
		userMapper.insert(user);
		return user.getUsername();
	}

	@Override
	public String login(String username, String password) throws JsonProcessingException {
		//将密码加密
		String md5Password = DigestUtils.md5Hex(password);
		
		User user = userMapper.findUserByU_P(username,md5Password);
		if(user !=null){
			//证明用户名和密码正确      
			//准备ticket 字符串  md5（“JT_TICKET_” + System.currentTime + username）
			String ticket = DigestUtils.md5Hex("JT_TICKET_" + System.currentTimeMillis()+username);
			String userJSON = objectMapper.writeValueAsString(user);
			
			//如果查询成功则将用户存入redis缓存中
			jedisCluster.set(ticket,userJSON);
			return ticket;
		}
		
		return null;
	}

}
