package com.jt.sso.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.jt.sso.pojo.User;

public interface UserService{
	
	//根据给定参数 查询数据是否存在
	public Boolean findCheckUser(String param, Integer type);
	
	//新增用户
	public String saveUser(User user);
	
	//根据用户名和密码登陆
	public String login(String username, String password) throws JsonProcessingException;

}
