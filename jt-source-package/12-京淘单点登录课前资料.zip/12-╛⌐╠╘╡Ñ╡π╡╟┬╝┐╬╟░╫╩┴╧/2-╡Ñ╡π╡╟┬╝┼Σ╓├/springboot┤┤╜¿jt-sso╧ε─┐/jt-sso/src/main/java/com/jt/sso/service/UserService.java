package com.jt.sso.service;

import java.util.List;

import com.jt.pojo.User;

public interface UserService {

	List<User> findAll();
	
}
