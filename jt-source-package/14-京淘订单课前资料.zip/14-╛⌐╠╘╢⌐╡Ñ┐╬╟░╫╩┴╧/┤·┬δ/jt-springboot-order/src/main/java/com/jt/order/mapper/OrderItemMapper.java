package com.jt.order.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jt.order.pojo.OrderItem;

public interface OrderItemMapper extends BaseMapper<OrderItem>{
}