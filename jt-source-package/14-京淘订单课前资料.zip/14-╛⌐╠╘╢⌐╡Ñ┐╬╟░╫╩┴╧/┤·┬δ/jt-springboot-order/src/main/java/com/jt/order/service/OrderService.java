package com.jt.order.service;

import com.jt.order.pojo.Order;

public interface OrderService {

	String saveOrder(Order order);

	Order findOrderById(String orderId);
	
	//修改超时订单
	void updateOrderStatus();

}
