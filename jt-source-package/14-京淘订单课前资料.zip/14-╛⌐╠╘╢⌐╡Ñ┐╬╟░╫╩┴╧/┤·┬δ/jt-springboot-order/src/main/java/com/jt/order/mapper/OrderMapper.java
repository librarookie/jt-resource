package com.jt.order.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jt.order.pojo.Order;

public interface OrderMapper extends BaseMapper<Order>{
}