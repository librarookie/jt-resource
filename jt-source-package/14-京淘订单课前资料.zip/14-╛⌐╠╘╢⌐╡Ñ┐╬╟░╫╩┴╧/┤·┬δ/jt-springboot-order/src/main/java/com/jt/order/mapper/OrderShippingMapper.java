package com.jt.order.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jt.order.pojo.OrderShipping;

public interface OrderShippingMapper extends BaseMapper<OrderShipping>{
  
}