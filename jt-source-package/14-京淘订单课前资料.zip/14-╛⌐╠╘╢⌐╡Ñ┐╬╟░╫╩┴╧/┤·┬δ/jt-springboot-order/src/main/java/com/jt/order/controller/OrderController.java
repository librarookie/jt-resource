package com.jt.order.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jt.order.pojo.Order;
import com.jt.order.service.OrderService;
import com.jt.order.vo.SysResult;

@RestController
@RequestMapping("/order")
public class OrderController {
	
	@Autowired
	private OrderService orderService;
	private ObjectMapper objectMapper = new ObjectMapper();
	
	@RequestMapping("/hello")
	public String hello() {
		
		return "你好世界";
	}
	
	//实现订单入库操作
	@RequestMapping("/create")
	public SysResult saveOrder(String orderJSON) {
		try {
			Order order = 
					objectMapper.readValue(orderJSON,Order.class);
			String orderId = orderService.saveOrder(order);
			return SysResult.oK(orderId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return SysResult.build(201,"新增订单失败");
	}
	
	@RequestMapping("/query/{orderId}")
	public Order findOrderById(@PathVariable String orderId) {
		
		return orderService.findOrderById(orderId);
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
