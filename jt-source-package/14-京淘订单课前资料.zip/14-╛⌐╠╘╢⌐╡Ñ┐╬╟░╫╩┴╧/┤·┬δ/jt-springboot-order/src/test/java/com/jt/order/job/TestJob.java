package com.jt.order.job;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import org.junit.Test;

import com.jt.order.vo.SysResult;

public class TestJob {
	
	//定时任务测试
	@Test
	public void testTimer() {
		TimerTask timerTask = new TimerTask() {
			@Override
			public void run() {
				//表示需要执行的任务
				System.out.println("我是定时任务:"+ new Date());
			}
		};
		
		//定义定时任务     只能执行指定间隔的任务
		Timer timer = new Timer();
		timer.schedule(timerTask,new Date(),3000);
		System.out.println("任务开始");
		while(true) {
			
		}
	}
	
}
