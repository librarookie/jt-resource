package com.jt.springcloud.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jt.springcloud.pojo.User;
import com.jt.springcloud.service.UserService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.ribbon.proxy.annotation.Hystrix;

@RestController
public class UserController {
	
	@Autowired
	public UserService userService;
	
	@RequestMapping("/getMsg")
	public String getMsg() {
		
		return "我是第一台服务端!!!";
	}
	
	@RequestMapping(value="/findAll")
	@HystrixCommand(fallbackMethod="hystrix_findAll") //需要配置注解使用仪表监控
	public List<User> findAll(){
		
		//throw new RuntimeException();
		return userService.findAll();
	}
	
	public List<User> hystrix_findAll(){
		User user = new User();
		user.setId(0);
		user.setName("后台服务器异常");
		user.setAge(0);
		user.setSex("");
		List<User> userList = new ArrayList<User>();
		userList.add(user);
		return userList; 
	}
	
	
	@RequestMapping("/saveUser")
	@HystrixCommand(fallbackMethod="hystrix_saveUser")
	public String saveUser(@RequestBody User user) {
		userService.saveUser(user);
		return "用户入库成功";
	}
	
	
	public String hystrix_saveUser(@RequestBody User user) {
		
		return "新增用户失败:"+user.getName();
	}
	
	@RequestMapping("/delete")
	public String deleteUser(Integer id) {
		
		userService.deleteUser(id);
		return "用户删除成功!!";
	}
	
	@RequestMapping("/updateUser")
	public String updateUser(@RequestBody User user) {
		
		userService.updateUser(user);
		return "用户更新成功!!!";
	}
	
	
	
	
	
	
}
