package com.jt.springcloud.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jt.springcloud.pojo.User;

public interface UserMapper extends BaseMapper<User>{
	
}
