package com.jt.manage.service;

import java.util.List;

import com.jt.manage.pojo.User;

public interface UserService {
	List<User> findUserAll();	//测试 查询全部用户信息
}
